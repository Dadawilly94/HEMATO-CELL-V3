# HEMATO-CELL V1.0 — architecture et périmètre

## Décisions produit
- Public : usage individuel et laboratoire hospitalier.
- Langues : français / anglais.
- Rapports : PDF et XLSX (Excel/LibreOffice).
- Référentiel : WHO-HAEM5 (5e édition, Volume 11, publication 2024).
- Mode : local-first ; aucune synchronisation distante activée dans ce paquet.

## Architecture
1. Présentation : Android natif, Kotlin, Jetpack Compose.
2. Domaine : définitions de populations cellulaires, comptages, pourcentages, rapport G:E exploratoire.
3. Données : Room/SQLite locale, identifiant de cas pseudonymisé.
4. Export : génération PDF via Android PdfDocument ; classeur XLSX Open XML minimal.
5. Synchronisation future : API HTTPS, authentification, chiffrement, audit, sauvegarde et stratégie de conflits. À concevoir et valider séparément.

## Périmètre fonctionnel de cette livraison
- Comptage manuel sang périphérique et moelle.
- Cibles de comptage 100 / 200 / 500 ; dépassement signalé.
- Pourcentages calculés sur le total effectivement compté.
- Fiches descriptives morphologiques FR/EN.
- Pages d'orientation pour LAM, LAL, LMC, LLC, SMD et néoplasies myéloprolifératives.
- Rapport G:E calculé à partir des cellules saisies dans la session, uniquement si les catégories granulocytaires et érythroblastiques ont été suffisamment renseignées.
- Sauvegarde locale des examens et export PDF/XLSX.

## Limites à ne pas masquer
- La liste de cellules et les fiches morphologiques sont une base pédagogique, pas un référentiel exhaustif.
- Le ratio G:E est un calcul descriptif et n'est pas interprétable si le comptage est incomplet, si des populations sont omises ou si la méthode locale diffère.
- Pas de reconnaissance d'images, pas d'interprétation automatisée, pas d'avis diagnostique.
- La synchronisation en ligne n'est pas implémentée. Ne pas stocker de données nominatives ni envoyer de données de santé à un serveur non validé.
- La validation par hématologiste/biologiste, tests analytiques, tests de sécurité, validation réglementaire et revue de protection des données sont obligatoires avant usage clinique.

## WHO-HAEM5 — sources de référence à consulter
- WHO Classification of Tumours Editorial Board. Haematolymphoid Tumours. WHO Classification of Tumours, 5th ed., Volume 11. IARC, 2024.
- Khoury JD, Solary E, Abla O, et al. The 5th edition of the WHO Classification of Haematolymphoid Tumours: Myeloid and Histiocytic/Dendritic Neoplasms. Leukemia. 2022;36:1703–1719. doi:10.1038/s41375-022-01613-1.
- Alaggio R, Amador C, Anagnostopoulos I, et al. The 5th edition of the WHO Classification of Haematolymphoid Tumours: Lymphoid Neoplasms. Leukemia. 2022;36:1720–1748. doi:10.1038/s41375-022-01620-2.

La classification et les critères peuvent évoluer : la version utilisée doit être indiquée dans chaque rapport et revue périodiquement.
