# HEMATO-CELL Android — V1.0 (source de développement)

Application Android native Kotlin / Jetpack Compose, conçue en mode local-first.

## Contenu livré
- Comptage manuel différentiel du sang et de la moelle.
- Cibles 100, 200 et 500 cellules.
- Pourcentages calculés sur le nombre réellement saisi.
- Rapport granulocytaire/érythroblastique (G:E) indicatif dans le module médullaire.
- Atlas textuel de morphologie FR/EN.
- Module d'orientation des principales hémopathies avec précautions diagnostiques.
- Sauvegarde locale Room/SQLite.
- Export de rapports PDF et classeurs XLSX.
- Choix de langue FR/EN.

## Construction
1. Installer Android Studio récent et JDK 17.
2. Ouvrir ce dossier dans Android Studio.
3. Synchroniser Gradle.
4. Lancer sur un émulateur ou un appareil Android (API 26+).
5. Pour distribuer : générer un APK signé depuis Build > Generate Signed Bundle / APK.

Le ZIP est un projet source, pas un APK précompilé. La compilation doit être exécutée dans Android Studio ; aucune compilation sur appareil n'a été vérifiée ici.

## Choix de V1.0
- Public : usage individuel et laboratoire hospitalier.
- Rapports : PDF + XLSX.
- Langues : français + anglais.
- Classification : WHO-HAEM5, 5e édition.
- Hors ligne : opérationnel par conception.
- Synchronisation distante : architecture prévue mais non activée dans cette livraison. Elle exige un serveur HTTPS sécurisé, authentification, chiffrement, audit, sauvegardes, gestion des conflits et validation de la protection des données.

Voir `docs/ARCHITECTURE_V1.md` pour le périmètre, les références et les limites.
